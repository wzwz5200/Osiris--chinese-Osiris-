#pragma once

#include <tuple>

std::tuple<float, float, float> rainbowColor(float speed) noexcept;
